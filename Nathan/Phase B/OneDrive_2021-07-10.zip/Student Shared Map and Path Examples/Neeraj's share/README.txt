README

- Updated 6:35 am, 8th July, 2021
- [NEW] The filenames have been changed to follow the specs and should work with the Automarker as well now.
- [NEW] An additional test(Map_09) was added.

1)[OLD] The filenames for the output and input files do not follow the PhaseB specs. Please ignore them.

2) The output log files are not confirmed to be 100% correct(though I'm fairly certain that they are). Please let me know if there are any errors.

3) - Map_02 -> single path
   - Map_05 -> empty
   - Map_06 -> low density horizontal walls only
   - Map_09 -> zig-zag, vertical walls only